// Asynchronous Client Engine //
// Global Chart Instances
let convergenceChartInstance = null;
let trajectoryChartInstance = null;

let iterationLabels = [];
let peakRiskData = [];
let currentRiskData = [];

// 1. Page Load hote hi Khali Charts Initialize karne ka function
function initializeEmptyCharts() {
    // Figure 6 Initialization
    const ctx6 = document.getElementById('convergenceChart').getContext('2d');
    convergenceChartInstance = new Chart(ctx6, {
        type: 'line',
        data: {
            labels: [],
            datasets: [
                { label: 'Max Risk Explored', data: [], borderColor: '#ff4560', borderWidth: 2, pointRadius: 0, fill: false },
                { label: 'Instant Step Risk', data: [], borderColor: '#00e396', borderWidth: 1, pointRadius: 1, fill: false }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { title: { display: true, text: 'Figure 6: Hybrid Search Optimization Curve', color: '#fff' } },
            scales: { x: { grid: { color: '#222' } }, y: { grid: { color: '#222' }, min: 0, max: 1000 } }
        }
    });

    // Figure 7 Initialization
    const ctx7 = document.getElementById('trajectoryChart').getContext('2d');
    trajectoryChartInstance = new Chart(ctx7, {
        type: 'line',
        data: {
            labels: Array.from({length: 30}, (_, i) => (i*0.1).toFixed(1)),
            datasets: [
                { label: 'Trajectory Error Profile', data: [], borderColor: '#58a6ff', borderWidth: 2, pointRadius: 0, fill: false },
                { label: 'Human Collision Boundary (12mm)', data: Array(30).fill(12.0), borderColor: '#ea4335', borderDash: [4, 4], pointRadius: 0, fill: false },
                { label: 'Object Drop Boundary (8mm)', data: Array(30).fill(8.0), borderColor: '#fbbc05', borderDash: [3, 3], pointRadius: 0, fill: false }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { title: { display: true, text: 'Figure 7: Spatial End-Effector Trajectory Deviation Profile', color: '#fff' } },
            scales: { x: { grid: { color: '#222' } }, y: { grid: { color: '#222' }, min: 0, max: 20 } }
        }
    });
}

// Run Initialization on Page Load
document.addEventListener("DOMContentLoaded", () => {
    initializeEmptyCharts();
});

// 2. Button Click Event Listener
document.getElementById('startStreamBtn').addEventListener('click', function() {
    this.disabled = true;
    
    // Reset Data arrays
    iterationLabels = [];
    peakRiskData = [];
    currentRiskData = [];
    
    document.getElementById('ros_terminal_box').innerHTML = "<div class='text-warning'>[SYSTEM] Connecting to Server-Sent Events backend channel...</div>";

    const rl_episodes = document.getElementById('rl_episodes').value || 30;
    const ga_pop_size = document.getElementById('ga_pop_size').value || 15;
    const ga_generations = document.getElementById('ga_generations').value || 6;

    // SSE Handshake
    const eventSource = new EventSource(`/stream_pipeline?rl_episodes=${rl_episodes}&ga_pop_size=${ga_pop_size}&ga_generations=${ga_generations}`);

    eventSource.onmessage = function(event) {
        const data = JSON.parse(event.data);
        
        // Metadata Updates
        document.getElementById('pipeline_phase').innerText = data.phase;
        document.getElementById('pipeline_counter').innerText = data.counter;
        document.getElementById('pipeline_max_risk').innerText = data.peak_risk.toFixed(2);

        // ROS Console Logger Logs Append
        const terminal = document.getElementById('ros_terminal_box');
        terminal.innerHTML = data.ros_logs.map(log => `<div>${log}</div>`).join('');
        terminal.scrollTop = terminal.scrollHeight;

        // Table 2 Row Generation Matrix
        updateTableMatrix(data.scenarios);

        // Update Figure 6 Dataset
        iterationLabels.push(data.counter);
        peakRiskData.push(data.peak_risk);
        currentRiskData.push(data.current_risk);

        convergenceChartInstance.data.labels = iterationLabels;
        convergenceChartInstance.data.datasets[0].data = peakRiskData;
        convergenceChartInstance.data.datasets[1].data = currentRiskData;
        convergenceChartInstance.update('none'); // Update without heavy layout reflows

        // Update Figure 7 Dataset
        trajectoryChartInstance.data.labels = data.trajectory.time.map(t => t.toFixed(1));
        trajectoryChartInstance.data.datasets[0].label = `Injected: ${data.trajectory.fault} (${data.trajectory.skill})`;
        trajectoryChartInstance.data.datasets[0].data = data.trajectory.error;
        trajectoryChartInstance.update('none');
    };

    eventSource.onerror = function(err) {
        console.log("Stream execution completed safely.");
        eventSource.close();
        document.getElementById('startStreamBtn').disabled = false;
        document.getElementById('ros_terminal_box').innerHTML += "<div class='text-info fw-bold mt-1'>[M2M SUCCESS] Structural model saved: 'system_risk_model.openpra'</div>";
    };
});

function updateTableMatrix(scenarios) {
    const tbody = document.getElementById('scenario_table_body');
    tbody.innerHTML = '';
    if(!scenarios || scenarios.length === 0) {
        tbody.innerHTML = `<tr><td colspan="6" class="text-muted py-2">Searching for crash profiles...</td></tr>`;
        return;
    }
    scenarios.forEach((scen, idx) => {
        tbody.innerHTML += `<tr class="font-monospace small">
            <td>${idx + 1}</td>
            <td class="text-warning">${scen.fault}</td>
            <td class="text-info">${scen.component}</td>
            <td>${scen.skill}</td>
            <td><span class="badge bg-danger">${scen.mode}</span></td>
            <td class="text-cyan fw-bold">${scen.risk}</td>
        </tr>`;
    });
}