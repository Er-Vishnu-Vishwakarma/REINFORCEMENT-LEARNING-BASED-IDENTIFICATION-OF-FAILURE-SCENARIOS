#Flask Main Backend Logic
import time
import random
import json
import numpy as np
from flask import Flask, render_template, jsonify, request, Response

app = Flask(__name__)

# SYSTEM PARAMETERS & HARDWARE CONFIGURATIONS
ROBOT_SKILLS = ["Object Detection", "Move to A", "Pick", "Carry to B", "Place"]
FAULT_TYPES = ["Bias", "Noise", "Stuck-At", "Packet_Loss", "Bit-Flips"]
COMPONENT_BASE_RATES = {
    "Camera_Image": 0.005,       
    "Joint_1_Signal": 0.002,
    "Joint_4_Signal": 0.002,
    "Gripper_State": 0.008,
    "Controller_Bus": 0.001
}

# MOCK ROS PARAMETER LOGGER
class ROSNodeSimulator:
    @staticmethod
    def generate_ros_logs(skill, component, fault_type, offset):
        timestamp = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
        return [
            f"[{timestamp}] [INFO] [ros.node.core]: Subscribed to /joint_states and /camera/image_raw",
            f"[{timestamp}] [INFO] [ros.skill.detector]: Active Skill Detected -> '{skill}'",
            f"[{timestamp}] [WARN] [ros.fault.injector]: Fault Active Triggered at offset {offset}s on channel: {component}",
            f"[{timestamp}] [ERROR] [ros.diagnostics]: Critical telemetry anomaly on hardware bus."
        ]

# DEEP LEARNING LATENT STATE FEATURE ENCODER
class DeepLearningStateEncoder:
    @staticmethod
    def encode_telemetry(trajectory_error_profile):
        max_deviation = np.max(np.abs(trajectory_error_profile)) if len(trajectory_error_profile) > 0 else 0
        if max_deviation > 12.0: return 3   # Human Safety Boundary Crossed
        elif max_deviation > 8.0: return 2   # Object Drop Boundary Crossed
        elif max_deviation > 4.0: return 1   # Minor System Deviation
        return 0                             # Nominal State

# RISKGPT REWARD SHAPER (LLM PARSER INTEGRATION)
class LLMRewardShaper:
    def __init__(self):
        self.llm_hazard_rules = {
            "Collision_with_Human": {"severity": 1.0, "base_reward": 600},
            "Object_Drop": {"severity": 0.8, "base_reward": 400},
            "Misidentification": {"severity": 0.5, "base_reward": 200}
        }
    def compute_shaped_reward(self, failure_mode, fault_tree_probability):
        if failure_mode in self.llm_hazard_rules:
            rule = self.llm_hazard_rules[failure_mode]
            return (rule["base_reward"] * rule["severity"]) + (fault_tree_probability * 200)
        return -15

# ADVANCED HYBRID RISK MODEL RESOLVER
class HybridRiskModelPipeline:
    @staticmethod
    def evaluate_fault_tree_logic(component, duration, fault_type):
        base_rate = COMPONENT_BASE_RATES.get(component, 0.002)
        modifier = 3.5 if fault_type in ["Stuck-At", "Bit-Flips"] else 1.5
        p_primary = min(0.90, base_rate * duration * modifier * 5)
        
        # Redundancy Fault Tree Logic via AND Gate
        if component in ["Joint_1_Signal", "Joint_4_Signal"]:
            p_backup = base_rate * duration * 0.4
            p_subsystem = p_primary * p_backup
        else:
            p_subsystem = p_primary
            
        # Software Bus Logic dependency via OR Gate
        p_software_bus = COMPONENT_BASE_RATES["Controller_Bus"] * duration
        return 1.0 - ((1.0 - p_subsystem) * (1.0 - p_software_bus))

    @staticmethod
    def solve_markov_transient_path(ft_prob, severity, sequence_steps=5):
        survival_probability = (1.0 - ft_prob) ** sequence_steps
        system_absorption_failure = 1.0 - survival_probability
        return system_absorption_failure * severity * 1000

    @staticmethod
    def export_to_openpra_format(unique_scenarios):
        openpra_schema = {
            "project_meta": {
                "framework": "Dynamic Risk Assessment",
                "export_timestamp": time.time()
            },
            "fault_tree_definitions": {
                "gate_and_nodes": ["Joint_1_Signal", "Joint_4_Signal"],
                "gate_or_nodes": ["Controller_Bus"]
            },
            "behavioral_profiles_discovered": unique_scenarios
        }
        with open("system_risk_model.openpra", "w") as f:
            json.dump(openpra_schema, f, indent=4)

# REINFORCEMENT LEARNING ADVERSARIAL FAULT AGENT
class QLearningFaultAgent:
    def __init__(self):
        self.q_table = np.zeros((4, len(FAULT_TYPES)))
    def choose_action(self, state_idx, epsilon=0.2):
        if random.random() < epsilon: return random.randint(0, len(FAULT_TYPES) - 1)
        return int(np.argmax(self.q_table[state_idx]))
    def update_policy(self, state, action, reward, next_state):
        best_next_action = np.argmax(self.q_table[next_state])
        td_target = reward + 0.95 * self.q_table[next_state][best_next_action]
        self.q_table[state][action] += 0.1 * (td_target - self.q_table[state][action])

# ENVIRONMENT WORKFLOW WITH GEOMETRIC & TEMPORAL INJECTIONS
class ROSControlledRobotEnv:
    def __init__(self):
        self.current_skill = random.choice(ROBOT_SKILLS)
        self.target_component = random.choice(list(COMPONENT_BASE_RATES.keys()))

    def inject_fault_and_stream(self, fault_type, magnitude, duration, time_offset):
        time_steps = np.linspace(0, duration, 30)
        
        # Modeling Cartesian Displacement profiles matching Figure 7 graphics
        if fault_type == "Bias":
            error_profile = (magnitude * 0.75 * (time_steps + time_offset))
        elif fault_type == "Noise":
            error_profile = np.random.normal(0, magnitude * 0.6, len(time_steps)) + (time_offset * 0.2)
        elif fault_type == "Stuck-At":
            error_profile = np.full(len(time_steps), magnitude * 2.2)
        else:
            error_profile = np.sin(time_steps + time_offset) * (magnitude * 1.5)
            
        max_disp = float(np.max(np.abs(error_profile)))
        triggered_mode = "Normal Execution"
        
        if max_disp > 12.0: triggered_mode = "Collision_with_Human"
        elif max_disp > 8.0 and self.current_skill in ["Pick", "Carry to B"]: triggered_mode = "Object_Drop"
        elif max_disp > 4.0 and self.target_component == "Camera_Image": triggered_mode = "Misidentification"
            
        state_idx = DeepLearningStateEncoder.encode_telemetry(error_profile)
        return triggered_mode, state_idx, time_steps.tolist(), error_profile.tolist()

# GENETIC ALGORITHM PARAMETER TUNING VECTOR CHROMOSOME
class FaultChromosome:
    def __init__(self):
        self.fault_type = random.choice(FAULT_TYPES)
        self.location = random.choice(list(COMPONENT_BASE_RATES.keys()))
        self.skill_phase = random.choice(ROBOT_SKILLS)
        self.magnitude = round(random.uniform(1.0, 7.0), 2)
        self.duration = round(random.uniform(0.5, 4.0), 2)
        self.injection_time_offset = round(random.uniform(0.0, 2.5), 2)
        self.fitness = 0.0

    def mutate(self):
        if random.random() < 0.3:
            self.magnitude = round(max(1.0, self.magnitude + random.uniform(-1, 1)), 2)
        if random.random() < 0.3:
            self.injection_time_offset = round(max(0.0, self.injection_time_offset + random.uniform(-0.5, 0.5)), 2)

rl_agent = QLearningFaultAgent()
llm_shaper = LLMRewardShaper()

@app.route('/')
def index():
    return render_template('dashboard.html', skills=ROBOT_SKILLS, faults=FAULT_TYPES, components=list(COMPONENT_BASE_RATES.keys()))

@app.route('/stream_pipeline')
def stream_pipeline():
    episodes = int(request.args.get('rl_episodes', 30))
    pop_size = int(request.args.get('ga_pop_size', 15))
    generations = int(request.args.get('ga_generations', 6))

    def event_stream():
        unique_scenarios = []
        highest_risk = 0.0
        counter = 1

        # PHASE 1: ADVERSARIAL REINFORCEMENT LEARNING EXPLORATION (FIGURE 6 PROGRESS)
        for ep in range(episodes):
            env = ROSControlledRobotEnv()
            state_idx = 0
            mag = round(random.uniform(2.0, 6.5), 2)
            dur = round(random.uniform(0.5, 4.0), 2)
            offset = round(random.uniform(0.0, 1.5), 2)
            
            act_idx = rl_agent.choose_action(state_idx)
            selected_fault = FAULT_TYPES[act_idx]
            
            mode, next_state, t_steps, err_prof = env.inject_fault_and_stream(selected_fault, mag, dur, offset)
            ft_prob = HybridRiskModelPipeline.evaluate_fault_tree_logic(env.target_component, dur, selected_fault)
            risk_score = HybridRiskModelPipeline.solve_markov_transient_path(ft_prob, 1.0 if mode == "Collision_with_Human" else 0.5)
            
            reward = llm_shaper.compute_shaped_reward(mode, ft_prob)
            rl_agent.update_policy(state_idx, act_idx, reward, next_state)
            
            ros_logs = ROSNodeSimulator.generate_ros_logs(env.current_skill, env.target_component, selected_fault, offset)

            if mode != "Normal Execution":
                scen = {"fault": selected_fault, "component": env.target_component, "skill": env.current_skill, "mode": mode, "risk": round(risk_score, 2)}
                if scen not in unique_scenarios: unique_scenarios.append(scen)
            
            if risk_score > highest_risk: highest_risk = risk_score
                
            payload = {
                "phase": "Reinforcement Learning Adversarial Search", "counter": counter, "peak_risk": highest_risk, "current_risk": risk_score,
                "scenarios": sorted(unique_scenarios, key=lambda x: x['risk'], reverse=True)[:6],
                "trajectory": {"time": t_steps, "error": err_prof, "fault": selected_fault, "component": env.target_component, "skill": env.current_skill},
                "ros_logs": ros_logs
            }
            yield f"data: {json.dumps(payload)}\n\n"
            counter += 1
            time.sleep(0.08)

        # PHASE 2: GENETIC ALGORITHM EXPLOITATION & FINE-TUNING
        population = [FaultChromosome() for _ in range(pop_size)]
        for gen in range(generations):
            for chrom in population:
                env = ROSControlledRobotEnv()
                env.current_skill = chrom.skill_phase
                env.target_component = chrom.location
                
                mode, _, t_steps, err_prof = env.inject_fault_and_stream(chrom.fault_type, chrom.magnitude, chrom.duration, chrom.injection_time_offset)
                ft_prob = HybridRiskModelPipeline.evaluate_fault_tree_logic(chrom.location, chrom.duration, chrom.fault_type)
                chrom.fitness = HybridRiskModelPipeline.solve_markov_transient_path(ft_prob, 1.0 if mode == "Collision_with_Human" else 0.5)
                
                ros_logs = ROSNodeSimulator.generate_ros_logs(chrom.skill_phase, chrom.location, chrom.fault_type, chrom.injection_time_offset)

                if mode != "Normal Execution":
                    scen = {"fault": chrom.fault_type, "component": chrom.location, "skill": chrom.skill_phase, "mode": mode, "risk": round(chrom.fitness, 2)}
                    if scen not in unique_scenarios: unique_scenarios.append(scen)
                
                if chrom.fitness > highest_risk: highest_risk = chrom.fitness
                
                payload = {
                    "phase": f"Genetic Algorithm Fine-Tuning (Gen {gen+1})", "counter": counter, "peak_risk": highest_risk, "current_risk": chrom.fitness,
                    "scenarios": sorted(unique_scenarios, key=lambda x: x['risk'], reverse=True)[:6],
                    "trajectory": {"time": t_steps, "error": err_prof, "fault": chrom.fault_type, "component": chrom.location, "skill": chrom.skill_phase},
                    "ros_logs": ros_logs
                }
                yield f"data: {json.dumps(payload)}\n\n"
                counter += 1
                time.sleep(0.08)

        # M2M MODEL EXPORT UPON COMPLETION
        HybridRiskModelPipeline.export_to_openpra_format(unique_scenarios)

    return Response(event_stream(), mimetype='text/event-stream')



# Yeh code browser ki MIME type script block security error ko bypass karega
@app.route('/static/js/charts.js')
def serve_charts_js():
    from flask import send_from_directory
    import os
    return send_from_directory(os.path.join(app.root_path, 'static', 'js'), 'charts.js', mimetype='application/javascript')
if __name__ == '__main__':
    app.run(debug=True, port=5000)